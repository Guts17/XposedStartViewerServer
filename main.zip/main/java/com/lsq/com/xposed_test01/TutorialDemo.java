package com.lsq.com.xposed_test01;

import android.content.res.XModuleResources;

import static de.robv.android.xposed.XposedHelpers.findAndHookMethod;

import de.robv.android.xposed.IXposedHookInitPackageResources;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.IXposedHookZygoteInit;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_InitPackageResources;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Created by Administrator on 2018-07-20.
 */

public class TutorialDemo implements IXposedHookLoadPackage,IXposedHookZygoteInit{

    private static String MODULE_PATH = null;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if(!lpparam.packageName.equals("android")){
            return;
        }
        XposedBridge.log("Loaded APP:" + lpparam.packageName);
        XposedBridge.log("We are in server.wm");
        findAndHookMethod("com.android.server.wm.WindowManagerService", lpparam.classLoader, "isSystemSecure", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                param.setResult(false);
            }
        });
    }

    @Override
    public void initZygote(StartupParam startupParam) throws Throwable {
        MODULE_PATH = startupParam.modulePath;
        XposedBridge.log("MODULE_PATH:" + MODULE_PATH);
    }

//    private static String MODULE_PATH = null;
//
//    @Override
//    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
//        if(!lpparam.packageName.equals("com.yaotong.crackme")){
//            return;
//        }
//        XposedBridge.log("Loaded APP:" + lpparam.packageName);
//        XposedBridge.log("We are in CrakeMe");
//        findAndHookMethod("com.yaotong.crackme.MainActivity", lpparam.classLoader, "securityCheck",String.class, new XC_MethodHook() {
//
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                param.setResult(true);
//            }
//        });
//
//    }
//
//    @Override
//    public void handleInitPackageResources(XC_InitPackageResources.InitPackageResourcesParam resparam) throws Throwable {
//        if(!resparam.packageName.equals("com.yaotong.crackme")){
//            return;
//        }
//        XModuleResources modRes = XModuleResources.createInstance(MODULE_PATH,resparam.res);
//        resparam.res.setReplacement("com.yaotong.crackme","drawable","creakme_bg2",modRes.fwd(R.mipmap.my_bg));
//    }
//
//    @Override
//    public void initZygote(StartupParam startupParam) throws Throwable {
//        MODULE_PATH = startupParam.modulePath;
//    }

}
